#!/bin/sh
if [ -f tttt ];then
    echo "rm file"
    rm tttt
fi
arm-eabi-objdump -S ./output/walle.elf > tttt
