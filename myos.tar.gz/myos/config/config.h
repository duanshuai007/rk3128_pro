#ifndef _CONFIG_H_
#define _CONFIG_H_

#define CONFIG_SYS_TEXT_BASE    0x50000000

#endif
