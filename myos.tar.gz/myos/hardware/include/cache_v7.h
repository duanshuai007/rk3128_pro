#ifndef _CACHE_V7_H_
#define _CACHE_V7_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>
//#include <string.h>

void flush_dcache_all(void);
void arm_init_before_mmu(void);
void mmu_page_table_flush(unsigned long start, unsigned long stop);

#ifdef __cplusplus
}
#endif

#endif
