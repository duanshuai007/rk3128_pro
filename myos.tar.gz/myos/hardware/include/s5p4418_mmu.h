#ifndef _S5P4418_MMU_H_
#define _S5P4418_MMU_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>
#include "cache_cp15.h"
#include "cache_v7.h"

void mmu_on(void);
void mmu_off(void);

#ifdef __cplusplus
}
#endif

#endif
