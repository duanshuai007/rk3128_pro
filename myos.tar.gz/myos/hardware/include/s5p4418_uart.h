#ifndef _S5P4418_UART_H_
#define _S5P4418_UART_H_

#include "types.h"

void Uart_Init(u8 channel, u32 baud, u8 databits, u8 parity, u8 stopbits);
void Uart_Write(u8 channel, u8 *buf, u8 len);
void Uart_Read(u8 channel, u8 *buf, u8 len);

#endif
