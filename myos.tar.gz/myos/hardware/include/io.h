#ifndef _IO_H_
#define _IO_H_

#define writel(a, v)    (*(volatile unsigned int *)(a) = (v))
#define readl(a)        (*(volatile unsigned int *)(a))

#endif
