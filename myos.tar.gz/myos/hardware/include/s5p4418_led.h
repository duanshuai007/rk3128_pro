#ifndef _S5P4418_LED_H_
#define _S5P4418_LED_H_

void my_led_init(void);
void my_led(int status);

#endif
