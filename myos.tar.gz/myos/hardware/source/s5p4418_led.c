#include <s5p4418_led.h>
#include <io.h>

#define GPIOC           0xC001C000
#define PULLSEL         0x58
#define PULLENB         0x60
#define PULLSEL_DIS     0x5c
#define PULLENB_DIS     0x64
#define OUTENB          0x04
#define OUT             0x00

#define GPIOC_PULLSEL           (GPIOC+PULLSEL)
#define GPIOC_PULLENB           (GPIOC+PULLENB)
#define GPIOC_PULLSEL_DISABLE   (GPIOC+PULLSEL_DIS)
#define GPIOC_PULLENB_DISABLE   (GPIOC+PULLENB_DIS)
#define GPIOC_OUTENB            (GPIOC+OUTENB)
#define GPIOC_OUT               (GPIOC+OUT)

void my_led_init(void)
{
    int val;
    //set pullsel
    val = readl(GPIOC_PULLSEL);
    val |= (1<<1);
    writel(GPIOC_PULLSEL, val);
    //set pullenb
    val = readl(GPIOC_PULLENB);
    val |= (1<<1);
    writel(GPIOC_PULLENB, val); 
    //set pillsel disable
    val = readl(GPIOC_PULLSEL_DISABLE);
    val |= (1<<1);
    writel(GPIOC_PULLSEL_DISABLE, val);
    //set pullenb disable
    val = readl(GPIOC_PULLENB_DISABLE);
    val |= (1<<1);
    writel(GPIOC_PULLENB_DISABLE, val);
    //set dir
    val = readl(GPIOC_OUTENB);
    val |= (1<<1);
    writel(GPIOC_OUTENB, val);   
}

void my_led(int status)
{
    int val;
    if(status)
    {   
        val = readl(GPIOC_OUT);
        val |= (1<<1);
        writel(GPIOC_OUT, val);
    }   
    else
    {   
        val = readl(GPIOC_OUT);
        val &= ~(1<<1);
        writel(GPIOC_OUT, val);
    }   
}
