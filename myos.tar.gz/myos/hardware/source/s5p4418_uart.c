#include "s5p4418_uart.h"
#include "types.h"
#include "io.h"

void Uart_Init(u8 channel, u32 baud, u8 databits, u8 parity, u8 stopbits)
{

}

void Uart_Write(u8 channel, u8 *buf, u8 len)
{

}

void Uart_Read(u8 channel, u8 *buf, u8 len)
{

}
