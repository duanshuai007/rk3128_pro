#include "s5p4418_led.h"
#include "io.h"

static void __my_delay(unsigned int x);
static void my_delay(unsigned int ms);
void copy_to_uboot(void);

char buffer[1024];
char memory[128] = {0};

extern unsigned int _end;

int first(int argc, char *argv[])
{
    unsigned int i = 10;
    my_led_init();

    writel(0x90000000, 0xab12de3f);
    writel(0xa0000000, 0x1234adfe);

    while(i--)
    {   
            my_led(1);
            my_delay(10);
            my_led(0);
            my_delay(100);
    }   
  
    return 0;
}

void copy_to_uboot(void)
{
    unsigned int addr = 0x42c00000;

    for(i=0xaffffda0; i < _end; i += 4)
    {
        writel(addr, readl(i));
        addr += 4;
    }
}

static void __my_delay(unsigned int x)
{
    volatile unsigned int i;
    for(i = 0; i < x; i++);
}

static void my_delay(unsigned int ms) 
{
    __my_delay(ms * 1000000);
}
